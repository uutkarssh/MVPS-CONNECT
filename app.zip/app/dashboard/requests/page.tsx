
"use client";

// This page is no longer used as staff approval has been removed.
export default function StaffRequestsPage() {
  return null;
}
