# **App Name**: MVPS Connect

## Core Features:

- Role-Based Login: Role-Based Login: Users choose between Student and Staff roles, with specific fields for each (Class/Roll No. for students, Role selection for staff).
- Teacher Setup Prompt: Teacher Setup: For Staff login with Teacher role, prompt to select Class Teacher status and subjects taught.
- Dynamic Dashboard: Dynamic Dashboard: Displays role-specific content after login, ensuring relevant information is prioritized.
- Notice Board: Notice Board: Allows all users to view notices, with admin roles (Principal/VP/Director) able to post and edit.
- Timetable Viewer: Timetable Viewer: Students can view their class schedule, while teachers can view/edit the timetable.
- Homework Module: Homework Module: Teachers can upload homework, and students can view it by subject.
- Exam & Result Section: Exam & Result Section: Facilitates uploading and viewing marks and exam schedules.

## Style Guidelines:

- Primary color: Deep blue (#2962FF) to represent trust, stability, and knowledge associated with education.
- Background color: Light gray (#F0F4F8) to provide a clean and modern backdrop, ensuring readability and focus on content.
- Accent color: Yellow-orange (#FFA000) to highlight important interactive elements, CTAs, and provide a warm, inviting feel.
- Headline font: 'Poppins' (sans-serif) for a modern and geometric feel, suitable for headlines. Body font: 'PT Sans' (sans-serif) to ensure legibility and readability of the application's body text.
- Use clean, outlined icons for navigation and features, ensuring clarity and visual appeal. Ensure all icons maintain consistent line thickness.
- Employ a card-based layout with rounded corners to display information in an organized and visually appealing manner.  The school logo should be visually prominent in the splash screen, login page and dashboard header.
- Incorporate subtle transitions and animations when navigating between sections to enhance user experience and provide visual feedback.