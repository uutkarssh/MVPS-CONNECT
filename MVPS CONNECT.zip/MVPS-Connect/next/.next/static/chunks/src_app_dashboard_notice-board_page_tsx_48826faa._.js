(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_8abf304e._.js",
  "static/chunks/src_390b80e4._.js"
],
    source: "dynamic"
});
