(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7206b4b1._.js",
  "static/chunks/node_modules_cfc075ba._.js"
],
    source: "dynamic"
});
