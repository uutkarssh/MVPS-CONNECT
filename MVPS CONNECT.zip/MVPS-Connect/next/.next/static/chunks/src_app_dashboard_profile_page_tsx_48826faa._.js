(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b10548cd._.js",
  "static/chunks/node_modules_2a148e69._.js",
  "static/chunks/node_modules_react-image-crop_dist_ReactCrop_28221f5b.css"
],
    source: "dynamic"
});
