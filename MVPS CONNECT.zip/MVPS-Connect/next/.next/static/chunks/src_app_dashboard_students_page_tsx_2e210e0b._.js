(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_4dd07095._.js",
  "static/chunks/src_3f19dffd._.js"
],
    source: "dynamic"
});
