(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_c89acba2._.js",
  "static/chunks/src_c0bc8161._.js"
],
    source: "dynamic"
});
