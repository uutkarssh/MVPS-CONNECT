(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_ffd2207d._.js",
  "static/chunks/node_modules_ebfb6f5b._.js"
],
    source: "dynamic"
});
