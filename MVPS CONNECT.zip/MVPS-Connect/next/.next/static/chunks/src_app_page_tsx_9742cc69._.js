(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_1c6eb809._.js",
  "static/chunks/node_modules_6134c8e4._.js"
],
    source: "dynamic"
});
